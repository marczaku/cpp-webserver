// HtinyD.cpp : Defines the entry point for the console application.
//
#include <SDKDDKVer.h>
#include <stdio.h>
#include <tchar.h>
#include <stdarg.h>

#pragma warning(disable:4996)
#define WIN32_LEAN_AND_MEAN

#include <Windows.h>
#include <WinSock2.h>
#include <conio.h>
#include <io.h>
#include <direct.h>
#include <process.h>

#pragma comment(lib, "ws2_32.lib")


//volatile deklarierten Variablen ohne jede Optimierung, d.h. l��t die entsprechenden Werte bei jedem Zugriff neu aus dem Hauptspeicher 
//laden und sorgt bei Ver�nderungen daf�r, da� die neuen Werte ohne Verz�gerung dort sofort abgelegt werden.

volatile bool g_bQuit=false;
volatile long g_iThreadCount=0;

char g_sContentPath[512];

void MainThread(void*);
void ConnectionThread(void*);

int _tmain(int argc, _TCHAR* argv[])
{
	{
		WSADATA WSAData;
		WSAStartup(MAKEWORD(2,1), &WSAData);
	};

	GetModuleFileNameA(NULL, g_sContentPath, 512);	//von exe
	{
		int i=(int)strlen(g_sContentPath)-1;
		while( (i>=0) && (g_sContentPath[i]!='\\') ){i--;}
		i--;
		while( (i>=0) && (g_sContentPath[i]!='\\') ){i--;}
		g_sContentPath[i+1]=0;
		strcat(g_sContentPath,"content");	//in den ContentBereich rubergehen
	}

	printf("Starting in path %s\r\n", g_sContentPath);

	_beginthread(MainThread,0,NULL);

	while(!g_bQuit)
	{
		if(kbhit())
		{
			char c = getch();
			if(c == 27)
			{
				g_bQuit = true;
			}
		}
		Sleep(50);
	};


	printf("Waiting for threads to finish\r\n");
	while(g_iThreadCount>0)//warten bis andere Threads durch sind
	{
		Sleep(50);
	}

	printf("Finished\r\n");
	WSACleanup();

	return 0;
}


struct ConParams
{
	SOCKET m_xSocket;
	sockaddr_in m_xAddr;
};

void MainThread(void*)
{
	::InterlockedIncrement(&g_iThreadCount);
	SOCKET xListen;
	// 0 alle Netzwerkinterfaces Post 80
	sockaddr_in xAddr;
	memset(&xAddr,0,sizeof(xAddr));
	xAddr.sin_family=AF_INET;
	xAddr.sin_port=htons(80);

	xListen = socket(AF_INET, SOCK_STREAM, 0);//socket offen
	//und an IP binden
	if(bind(xListen,(struct sockaddr*)&xAddr, sizeof(xAddr))!=0)
	{
		printf("Can't open listen socket (%d)\r\n", WSAGetLastError());
		closesocket(xListen);
		::InterlockedDecrement(&g_iThreadCount);
		return;
	};
	// Listen-Mode, kann neue Verbindungen aufbauen.
	if(listen(xListen,SOMAXCONN)!=0)
	{
		printf("Can't listen on socket(%d)\r\n",WSAGetLastError());
		closesocket(xListen);
		::InterlockedDecrement(&g_iThreadCount);
		return;
	}
	// Non-blocking: Damit er nicht wartet, bis eine neue Verbindung kommt, sondern auch ohne fortf�hrt.
	unsigned long iArg=1;
	ioctlsocket(xListen,FIONBIO,&iArg);
	iArg=1;
	setsockopt(xListen,SOL_SOCKET,SO_REUSEADDR,(const char*)&iArg,sizeof(long));
	while(!g_bQuit)
	{
		// Accept, um Verbindungen anzunehmen. Da wir darauf warten wollen, nehmen wir die Methode Select
		// Damit kann man auf eingehende, ausgehende Sockets und Fehler checken und warten.
		fd_set xFS;
		xFS.fd_count=1;
		xFS.fd_array[0]=xListen;
		TIMEVAL xTime;
		xTime.tv_sec=0;
		xTime.tv_usec=50000;
		if(select(1,&xFS,NULL,NULL,&xTime)>0)
		{
			ConParams* pxParams=new ConParams();
			int iClientAddrSize=sizeof(pxParams->m_xAddr);
			pxParams->m_xSocket=accept(xListen,(sockaddr*)&pxParams->m_xAddr,&iClientAddrSize);
			if(pxParams->m_xSocket==INVALID_SOCKET)
			{
				delete pxParams;
			}
			else
			{
				_beginthread(ConnectionThread,0,(void*)pxParams);
			}
		}
	};

	closesocket(xListen);
	::InterlockedDecrement(&g_iThreadCount);

};


void ConnectionThread(void* p_pArg)
{
	enum {BUFSIZE=1024*1024};
	ConParams* pxParams=(ConParams*)p_pArg;
	::InterlockedIncrement(&g_iThreadCount);
	printf("Connection thread started %d.%d.%d.%d:%d\r\n",
		pxParams->m_xAddr.sin_addr.S_un.S_un_b.s_b1,
		pxParams->m_xAddr.sin_addr.S_un.S_un_b.s_b2,
		pxParams->m_xAddr.sin_addr.S_un.S_un_b.s_b3,
		pxParams->m_xAddr.sin_addr.S_un.S_un_b.s_b4,
		ntohs(pxParams->m_xAddr.sin_port));
	char* sBuf=new char[BUFSIZE];

	bool bReqComplete=false;
	int iBufPos=0;

	unsigned long iArg=1;
	ioctlsocket(pxParams->m_xSocket,FIONBIO,&iArg);

	int iTimeout=0;
	while(!g_bQuit&&!bReqComplete)
	{
		int iS=recv(pxParams->m_xSocket,sBuf+iBufPos,
			BUFSIZE-iBufPos-1,0);
		if(iS==0)
		{
			Sleep(5);
			iTimeout++;
			if(iTimeout>1000)
			{
				bReqComplete=true;
				iBufPos=0;
			}
		}
		else if(iS<0)
		{
			if(WSAGetLastError()==WSAEWOULDBLOCK)
			{
				Sleep(5);
				iTimeout++;
				if(iTimeout>1000)
				{
					bReqComplete=true;
					iBufPos=0;
				}
			}
			else
			{
				bReqComplete=true;
				iBufPos=0;
			}
		}
		else if(iS>0)
		{
			iBufPos+=iS;
			if(iBufPos>=BUFSIZE-1)
			{
				bReqComplete=true;
			}
			else
			{
				if((sBuf[iBufPos-4]=='\r')&&(sBuf[iBufPos-3]=='\n') &&
					(sBuf[iBufPos-2]=='\r')&&(sBuf[iBufPos-1]=='\n'))
				{
					bReqComplete=true;
				}
			}
		}
	}
	if((iBufPos>0)&&(bReqComplete))
	{
		sBuf[iBufPos]=0;
		printf("%s\r\n",sBuf);

		int iFileSize=-1;
		int iEndPos=0;

		{
			int i=0;
			char* sUrl=NULL;
			while((i<iBufPos)&&(sBuf[i]!='\r'))
			{
				if(sBuf[i]==' ')
				{
					if(sUrl==NULL)
					{
						sUrl=sBuf+i+1;
					}
					sBuf[i]=0;
				}
				i++;
			}
			if(strcmp(sUrl,"/")==0)
			{
				strcat(sUrl,"index.html");
			}
			char sFileName[512];
			strcpy(sFileName,g_sContentPath);
			strcat(sFileName,sUrl);
			
			FILE* pFile=NULL;
			pFile=fopen(sFileName,"rb");
			if(!pFile)
			{
				printf("404:'%s'\r\n",sUrl);
				iFileSize=-1;

				strcpy(sBuf,"HTTP/1.0 404 Not Found\r\n\r\n<html>"
					"<head><title>404</title></head>"
					"<body>Oh noes!</body></html>\r\n\r\n");
				iEndPos=(int)strlen(sBuf);
			}
			else
			{
				fseek(pFile,0,SEEK_END);
				iFileSize=ftell(pFile);
				fseek(pFile,0,SEEK_SET);
				if(iFileSize+100>BUFSIZE){iFileSize=BUFSIZE-100;}
				printf("200:'%s' (%d\r\n",sUrl,iFileSize);
				sprintf_s(sBuf,BUFSIZE,"HTTP/1.0 200 OK\r\n"
					"Content-Length:%d\r\n\r\n",iFileSize);
				int iHeaderLen=(int)strlen(sBuf);
				fread(sBuf+iHeaderLen,iFileSize,1,pFile);
				iEndPos=iHeaderLen+iFileSize;
				fclose(pFile);
			}
		}
		iBufPos=0;
		iTimeout=0;
		while(!g_bQuit&&(iBufPos<iEndPos))
		{
			int iS=send(pxParams->m_xSocket,sBuf+iBufPos,iEndPos-iBufPos,0);
			if(iS<0)
			{
				if(WSAGetLastError()==WSAEWOULDBLOCK)
				{
					Sleep(5);
					iTimeout++;
					if(iTimeout>5000)
					{
						iBufPos=0;
					}
				}
				else
				{
					iBufPos=iEndPos;
				}
			}
			else
			{
				iBufPos+=iS;
			}
		}
	}

	//processing
	shutdown(pxParams->m_xSocket,SD_BOTH);
	closesocket(pxParams->m_xSocket);
	delete[] sBuf;
	delete pxParams;
	::InterlockedDecrement(&g_iThreadCount);

}