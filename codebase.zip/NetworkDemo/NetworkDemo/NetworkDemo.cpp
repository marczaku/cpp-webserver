// NetworkDemo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "IPAddr4.h"
#include "UDPSocket.h"

void UDPTest();

int _tmain(int argc, _TCHAR* argv[])
{
	UDPTest();
	return 0;
}

void ChatServer(const IPAddr4& p_xAddr);
void ChatClient(const IPAddr4& p_xAddr);

#define UDP_DEFAULTSERVERPORT "localhost:1234"

void UDPTest()
{
	WinsockInitHolder WsIH;

	enum {MAXBUFSIZE=512};
	char* sBuf=new char[MAXBUFSIZE];

	IPAddr4 xServerAddr;
	printf("Enter server address and port (%s):",UDP_DEFAULTSERVERPORT);
	gets(sBuf);
	if(strlen(sBuf)==0)
		strcpy(sBuf,UDP_DEFAULTSERVERPORT);
	xServerAddr.Set(sBuf);
	xServerAddr.Dump();

	printf("[S]erver or [C]lient?");
	char c=getch();
	if(c=='s')
	{
		printf(" > Server...\n");
		ChatServer(xServerAddr);
	};
	if(c=='c')
	{
		printf(" > Client...\n");
		ChatClient(xServerAddr);
	};
	delete[] sBuf;

	PrintLastSockError();
}

void ChatServer(const IPAddr4& p_xAddr)
{
	enum{MAXCLIENTS=128};
	IPAddr4 axClients[MAXCLIENTS];

	UDPSocket xS;

	if(!xS.Open(p_xAddr))
		return;

	bool bDone=false;
	enum{MAXBUFSIZE=512};
	char* sBuf;
	sBuf=new char[MAXBUFSIZE];

	while(!bDone)
	{
		if(kbhit())
		{
			char c=getch();
			if(c==27)
				bDone=true;
		}
		int iPending=xS.GetPendingReadData();
		if(iPending>0)
		{
			IPAddr4 xFrom;
			iPending=xS.RecvFrom(xFrom,sBuf,MAXBUFSIZE-1);
			if(iPending>0)
			{
				sBuf[iPending]=0;
				printf("%d.%d.%d.%d: ",xFrom.sin_addr.S_un.S_un_b.s_b1,
					xFrom.sin_addr.S_un.S_un_b.s_b2,
					xFrom.sin_addr.S_un.S_un_b.s_b3,
					xFrom.sin_addr.S_un.S_un_b.s_b4);
				printf("%s\n",sBuf);
				int iNewIdx=-1;
				int i;
				for(i=0;i<MAXCLIENTS;i++)
				{
					if(axClients[i]==xFrom)
						iNewIdx=-2;
					else if((iNewIdx==-1)&&(axClients[i].GetPort()==0))
						iNewIdx=i;
					else if(axClients[i].GetPort()!=0)
					{
						xS.SendTo(axClients[i],sBuf,iPending);
					}
				}
				if(iNewIdx>=0)
				{
					axClients[iNewIdx]=xFrom;
					printf("New client.\n");
				}
			}
		}
		xS.WaitRead(100);
	}
	delete[] sBuf;
}

void ChatClient(const IPAddr4& p_xAddr)
{
	UDPSocket xS;

	if(!xS.Open())
		return;

	enum {MAXBUFSIZE=512};
	char* sBuf;
	sBuf=new char[MAXBUFSIZE];

	bool bDone=false;

	DWORD dwSize=MAXBUFSIZE-3;
	GetUserNameA(sBuf,&dwSize);
	strcat(sBuf,": ");
	int iNameLen=(int)strlen(sBuf);
	char* sBufAfter = sBuf+iNameLen;

	sBufAfter[0]=0;
	xS.SendTo(p_xAddr,sBufAfter,1);

	while(!bDone)
	{
		if(kbhit())
		{
			char c=getch();
			if(c==27)
				bDone=true;
			if(c=='\r')
			{
				printf(">");
				gets_s(sBufAfter,MAXBUFSIZE-1-iNameLen);
				int iL=(int)strlen(sBufAfter);
				if(iL>0)
				{
					sBuf[iL+iNameLen]=0;
					xS.SendTo(p_xAddr,sBuf,iL+iNameLen);
				}
			}
		}
		int iPending=xS.GetPendingReadData();
		if(iPending>0)
		{
			IPAddr4 xFrom;
			iPending=xS.RecvFrom(xFrom,sBufAfter,MAXBUFSIZE-1-iNameLen);
			if(iPending>0)
			{
				sBufAfter[iPending]=0;
				if(strlen(sBufAfter)>0)
				{
					printf("%s\r\n",sBufAfter);
				}
			}
		}
		xS.WaitRead(100);
	}
	delete [] sBuf;
}