#include "stdafx.h"
#include "UDPSocket.h"

UDPSocket::UDPSocket()
{
	m_xSock=INVALID_SOCKET;
	m_hReadEvt=WSA_INVALID_EVENT;
}

UDPSocket::~UDPSocket()
{
	Close();
}

bool UDPSocket::Open(const IPAddr4& p_xLocalAddr)
{
	Close();
	m_xSock=WSASocket(AF_INET,SOCK_DGRAM,IPPROTO_UDP,NULL,0,WSA_FLAG_OVERLAPPED);
	if(m_xSock==INVALID_SOCKET){return false;}
	if(bind(m_xSock,(const sockaddr*)&p_xLocalAddr,sizeof(p_xLocalAddr))!=0)
	{
		Close();
		return false;
	}
	m_hReadEvt=WSACreateEvent();
	WSAEventSelect(m_xSock,m_hReadEvt,FD_READ);
	return true;
}

bool UDPSocket::Open()
{
	Close();
	m_xSock=WSASocket(AF_INET,SOCK_DGRAM,IPPROTO_UDP,NULL,0,WSA_FLAG_OVERLAPPED);
	if(m_xSock==INVALID_SOCKET){return false;}
	m_hReadEvt=WSACreateEvent();
	WSAEventSelect(m_xSock,m_hReadEvt,FD_READ);
	return true;
}

void UDPSocket::Close()
{
	if(m_xSock!=INVALID_SOCKET)
	{
		shutdown(m_xSock,SD_BOTH);
		closesocket(m_xSock);
		m_xSock=INVALID_SOCKET;
	}
	if(m_hReadEvt!=WSA_INVALID_EVENT)
	{
		WSACloseEvent(m_hReadEvt);
		m_hReadEvt=WSA_INVALID_EVENT;
	}
}

bool UDPSocket::IsOpen()
{
	return m_xSock!=INVALID_SOCKET;
}

int UDPSocket::GetPendingReadData()
{
	if(m_xSock==INVALID_SOCKET){return -1;}
	DWORD uSize;
	int iRet=ioctlsocket(m_xSock,FIONREAD,&uSize);
	if(iRet!=0){return -1;}
	return uSize;
}

bool UDPSocket::WaitRead(int p_iTimeOut)
{
	if(p_iTimeOut<0){return false;}
	if(m_xSock==INVALID_SOCKET){::Sleep(p_iTimeOut);return false;}
	if(WSAWaitForMultipleEvents(1,&m_hReadEvt,FALSE,p_iTimeOut,FALSE)
		==WSA_WAIT_EVENT_0)
	{
		WSAResetEvent(m_hReadEvt);
		return true;
	}
	return false;
}

int UDPSocket::SendTo(const IPAddr4& p_xRemoteAddr,void* p_pData, int p_iDataSize)
{
	return sendto(m_xSock,(const char*)p_pData, p_iDataSize, 0,
		(const sockaddr*)&p_xRemoteAddr,sizeof(p_xRemoteAddr));
}

int UDPSocket::RecvFrom(IPAddr4& po_xRemoteAddr,void* p_pData, int p_iDataSize)
{
	int iAddrSize=sizeof(po_xRemoteAddr);
	return recvfrom(m_xSock,(char*)p_pData,p_iDataSize,0,
		(sockaddr*)&po_xRemoteAddr,&iAddrSize);
}