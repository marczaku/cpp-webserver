#ifndef UDPSOCKET_H
#define UDPSOCKET_H

#include "IPAddr4.h"

class UDPSocket
{
	WSAEVENT m_hReadEvt;
	SOCKET m_xSock;
	UDPSocket(const UDPSocket&);
	UDPSocket& operator=(const UDPSocket&);
public:

	UDPSocket();
	~UDPSocket();

	bool Open(const IPAddr4& p_xLocalAddr);
	bool Open();
	void Close();

	bool IsOpen();
	int GetPendingReadData();
	bool WaitRead(int p_iTimeOut);

	int SendTo(const IPAddr4& p_xRemoteAddr,void* p_pData, int p_iDataSize);
	int RecvFrom(IPAddr4& po_xRemoteAddr,void* p_pData, int p_iDataSize);
};

#endif